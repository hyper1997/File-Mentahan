# Moded Magisk Manager to perfect run ANDRAX

## FIX Screen ISSUES AND NEW BUGS IN SUPERUSER

### How to INSTALL?

Simple, to install **YOU NEED REMOVE COMPLETELY SUPERSU OR OFICIAL MAGISK**. So download [MAGISK-ANDRAX-MOD.ZIP](https://github.com/gnubrasil/magisk-andrax-mod/releases/)

### Modules

MAGISK-ANDRAX-MOD has compatibility with the modules of the official magisk

##Como instalar?

 Simples de instalar, VOCÊ PRECISA REMOVER COMPLETAMENTE SUPERSU OU MAGISK OFICIAL.  Faça o download do MAGISK-ANDRAX-MOD.ZIP

 Módulos
 O MAGISK-ANDRAX-MOD tem compatibilidade com os módulos do magisk oficial
