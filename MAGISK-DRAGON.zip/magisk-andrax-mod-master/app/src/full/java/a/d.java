package a;

import com.topjohnwu.magisk.AboutActivity;

public class d extends AboutActivity {
    /* stub */
}
