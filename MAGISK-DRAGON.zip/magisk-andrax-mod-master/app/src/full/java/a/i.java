package a;

import com.topjohnwu.magisk.receivers.PackageReceiver;

public class i extends PackageReceiver {
    /* stub */
}
