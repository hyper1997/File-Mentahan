package a;

import com.topjohnwu.magisk.receivers.BootReceiver;

public class h extends BootReceiver {
    /* stub */
}
