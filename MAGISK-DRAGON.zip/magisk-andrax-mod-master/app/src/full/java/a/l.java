package a;

import com.topjohnwu.magisk.receivers.ShortcutReceiver;

public class l extends ShortcutReceiver {
    /* stub */
}
