package a;

import com.topjohnwu.magisk.DonationActivity;

public class e extends DonationActivity {
    /* stub */
}
