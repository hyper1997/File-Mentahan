# Magisk Manager
This repo is no longer an independent component. It is merged into the [Magisk Project](https://github.com/topjohnwu/Magisk).

# Translations
The default (English) strings are mainly in `src/full/res/values/strings.xml`; some are scattered in `src/main/res/values/strings.xml` and `src/stub/res/values/strings.xml`.  
Translations are highly appreciated via pull requests here on Github.  
Place translated XMLs in the corresponding locale folder.
