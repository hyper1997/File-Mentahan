package com.topjohnwu.magisk.components;

import android.app.Activity;

public abstract class FlavorActivity extends Activity {}
