package a;

import com.topjohnwu.magisk.receivers.ManagerUpdate;

public class j extends ManagerUpdate {
    /* stub */
}
